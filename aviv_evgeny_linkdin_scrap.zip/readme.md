### linkedin jobs scrapper

This project outomatically openes a webdriver and collects all info from a linkdin job list.
* currently set for data science jobs in Israel.
* prints info of collected jobs to stdout
* web driver operates in chrome (incognito) mode

setup chromedriver before running this project by following the setup
section in this link: https://chromedriver.chromium.org/getting-started

Install requirments `pip install -r /path/to/requirements.txt`

To lunch the program: `python main.py`

remote repo:  https://github.com/AvivTahar/DataScrapingProject.git